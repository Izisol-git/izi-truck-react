import React from 'react';

function ChatsPagination() {
    return (
        <div>

        </div>
    );
}

export default ChatsPagination;