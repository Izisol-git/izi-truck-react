import * as React from "react";
import Switch from "@mui/material/Switch";

const label = { inputProps: { "aria-label": "Switch demo" } };

const SwitchMUI = () => {
    return (
        <div>
            <Switch
                {...label}

                sx={{
                    "& .MuiSwitch-switchBase.Mui-checked": {
                        color: "#1D2D5B",
                    },
                    "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
                        backgroundColor: "#1D2D5B",
                    },
                    '.dark  & .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track  ':{
                        backgroundColor: "#444444",

                    },
                    ".dark & .MuiSwitch-switchBase.Mui-checked": {
                        color: "#2B4764",
                    }
                }}
            />
        </div>
    );
};

export default SwitchMUI;
