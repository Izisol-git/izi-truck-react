

export const inputModalArray = [
    { type: "text", label: "clients.inputModalArray.company_name", value: "", post: "company_name" },
    { type: "text", label: "clients.inputModalArray.fio", value: "", post: "fio" },
    { type: "text", label: "clients.inputModalArray.phone_number", value: "", post: "phone_number" },
    { type: "text", label: "clients.inputModalArray.contract_no", value: "", post: "contract_no" },
    { type: "text", label: "clients.inputModalArray.director_position", value: "", post: "director_position" },
    { type: "text", label: "clients.inputModalArray.director", value: "", post: "director" },
    { type: "text", label: "clients.inputModalArray.director_add", value: "", post: "director_add" },
    { type: "text", label: "clients.inputModalArray.customer", value: "", post: "customer" },
    { type: "text", label: "clients.inputModalArray.cust_bank_code", value: "", post: "cust_bank_code" },
    { type: "text", label: "clients.inputModalArray.customer_bank", value: "", post: "customer_bank" },
    { type: "text", label: "clients.inputModalArray.customer_bank_acc", value: "", post: "customer_bank_acc" },
    { type: "text", label: "clients.inputModalArray.customer_tin", value: "", post: "customer_tin" },
    { type: "text", label: "clients.inputModalArray.customer_address", value: "", post: "customer_address" },
    { type: "text", label: "clients.inputModalArray.customer_vat", value: "", post: "customer_vat" },
    { type: "text", label: "clients.inputModalArray.acc_tel", value: "", post: "acc_tel" },
    { type: "text", label: "clients.inputModalArray.treaty_code", value: "", post: "treaty_code" },
    { type: "text", label: "clients.inputModalArray.customer_oked", value: "", post: "customer_oked" },
    { type: "date", label: "clients.inputModalArray.created_at", value: "", post: "created_at" }
];
