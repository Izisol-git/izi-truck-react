

export  const inputModalArray  =   [
    {type:'select' , label:'Is Active', value:''},
    {type:'select' , label:'All Employee Access', value:''},
    {type:'text' , label:'Name', value:''},
    {type:'text' , label:'Phone Number 1', value:''},
    {type:'text' , label:'Phone Number 2', value:''},
    {type:'text' , label:'Passport Number', value:''},
    {type:'text' , label:'PINFL', value:''},

]