export const inputModalArray = [
    { type: "select", label: "employees.inputModalArray.user_type", value: "", post: "type", superAdmin: true },
    { type: "text", label: "employees.inputModalArray.full_name", value: "", post: "name" },
    { type: "text", label: "employees.inputModalArray.phone_number", value: "", post: "phone_number" },
    { type: "text", label: "employees.inputModalArray.tg_user_id", value: "", post: "tg_user_id" },
    { type: "text", label: "employees.inputModalArray.tg_nick_name", value: "", post: "tg_nick_name" },
    { type: "email", label: "employees.inputModalArray.email", value: "", post: "email" },
    { type: "password", label: "employees.inputModalArray.password", value: "", post: "password" },
    { type: "text", label: "employees.inputModalArray.code", value: "", post: "code" },
    { type: "text", label: "employees.inputModalArray.tin", value: "", post: "tin" }
];
