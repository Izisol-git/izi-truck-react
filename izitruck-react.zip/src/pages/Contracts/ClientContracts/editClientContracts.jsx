import React from 'react';
import {AddClientContracts} from "../../index.js";

function EditClientContracts() {
    return (
        <div>
            <AddClientContracts  mode={'edit'} />
        </div>
    );
}

export default EditClientContracts;