import React from 'react';

function EmployeesContracts(props) {
    return (
        <div>EmployeesContracts</div>
    );
}

export default EmployeesContracts;