import React from "react";
import {
    DriversFrom,
} from "../../../Components/index.js";


function AddDrivers() {
    return (
        <DriversFrom mode={'add'}/>
    );
}

export default AddDrivers;
