import React from "react";
import { DriversFrom} from "../../../Components/index.js";

function EditDrivers() {

    return (
        <DriversFrom mode={'edit'}/>
    );
}

export default EditDrivers;
