import React from 'react';
import {Navbar} from "../../../Components/index.js";

function Home() {
    return (
        <div>
            Home
        </div>
    );
}

export default Home;