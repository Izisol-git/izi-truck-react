import React from 'react';
import {QueriesFrom} from "../../Components/index.js";

function AddQueries() {


    return (
       <>
           <QueriesFrom  mode={'add'}  />
       </>
    );
}

export default AddQueries;