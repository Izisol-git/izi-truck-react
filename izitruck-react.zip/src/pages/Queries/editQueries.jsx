import React from 'react';
import {QueriesFrom} from "../../Components/index.js";

function EditQueries() {
    return (
        < >
            <QueriesFrom mode={'edit'}  />
        </ >
    );
}

export default EditQueries;