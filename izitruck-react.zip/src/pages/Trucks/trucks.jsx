import React from 'react';
import {Navbar} from "../../Components/index.js";

function Trucks() {
    return (
        <>

            <div>trucks</div>
        </>
    );
}

export default Trucks;